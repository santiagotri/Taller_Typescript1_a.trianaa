import { Course } from './course.js';

export const dataCourses = [
  new Course("Ingeniería de Sw", "Jose Bocanegra", 3),
  new Course("Diseño y analisis de algoritmos", "Rodrigo Cardoso",3),
  new Course("Sistemas transaccionales", "German Bravo", 3),
  new Course("Fundam. admon. y gerencia", "Juan Pablo Castillo", 3),
  new Course("Taller habilidades informaticas", "Martha Caceres", 1),
  new Course("Calculo vectorial", "Jairo Angel", 3)
]